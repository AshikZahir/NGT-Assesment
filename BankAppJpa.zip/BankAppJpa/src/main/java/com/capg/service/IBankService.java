package com.capg.service;

import javax.persistence.EntityManager;

public interface IBankService {

	public EntityManager getManager();
	public boolean validateAccountName(String accountName);
	public boolean validateAccountId(String accountId);
	
}
