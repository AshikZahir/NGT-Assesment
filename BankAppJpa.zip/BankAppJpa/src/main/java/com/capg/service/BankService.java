package com.capg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class BankService implements IBankService{
	
	private static EntityManagerFactory factory; 
	private static EntityManager manager;
	static{
		factory= Persistence.createEntityManagerFactory("mypu");
	}
	
	public EntityManager getManager() {
		
		if(manager==null || !manager.isOpen())
			manager=factory.createEntityManager();
		else
			getManager();
		return manager;
	}
	
	public boolean validateAccountName(String accountName) {
		String pattern="^[a-zA-Z]*$";
        return accountName.matches(pattern);
	}

	public boolean validateAccountId(String accountId) {
		 String pattern="^[1-9]{7}-[A-Z]{4}$";
			return accountId.matches(pattern);	
		
	}
}
