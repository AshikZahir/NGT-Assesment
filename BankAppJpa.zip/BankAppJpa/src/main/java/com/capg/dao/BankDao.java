package com.capg.dao;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capg.bean.Account;
import com.capg.bean.Loan;
import com.capg.bean.Transaction;
import com.capg.service.BankService;

public class BankDao implements IBankDao{
	
		BankService con;
	EntityManager em;
	public BankDao(){
		con=new BankService();
		em= con.getManager();
	}

	public void createAccount(Account a) {
		
		em.getTransaction().begin();
		em.persist(a);
		em.flush();
		em.getTransaction().commit();
		System.out.println("Account Created successfully");
	}
	
	public double deposit(String id, double depositAmount) {
		
		em.getTransaction().begin();
		TypedQuery<Account> query = em.createQuery("select a from Account a where a.accountId= ?1", Account.class);
		query.setParameter(1,id);
        double accBal= query.getSingleResult().getDepositAmount();
        TypedQuery<Account> tl = (TypedQuery<Account>) em.createQuery("update Account a set a.depositAmount = ?1 where a.accountId= ?2");
        tl.setParameter(1, accBal+depositAmount);
        tl.setParameter(2, id);
        int i=tl.executeUpdate();
        em.getTransaction().commit();
       if(i>0)
		return accBal+depositAmount;
	   return -1;
	}
	
	public void applyLoan(Loan loan) {
		
		em.getTransaction().begin();
		em.persist(loan);
		em.flush();
		em.getTransaction().commit();
		System.out.println("Loan is applied successfully");
	}
	
	public double withdraw(String id, double withdraw)  {
		
		em.getTransaction().begin();
		TypedQuery<Account>  query = em.createQuery("select acc from Account acc where acc.accountId= ?1",Account.class);
		query.setParameter(1,id);
        double  accBal= query.getSingleResult().getDepositAmount();
        TypedQuery<Account> tl = (TypedQuery<Account>) em.createQuery("update Account acc set acc.depositAmount = ?1 where acc.accountId= ?2");
        tl.setParameter(1, accBal-withdraw);
        tl.setParameter(2, id);
        int i=tl.executeUpdate();
        em.getTransaction().commit();
       if(i>0)
		return accBal-withdraw;
	   return -1;
	}
	
	public Account getAccDetails(String accId) {
		em.getTransaction().begin();
		
		Query q = em.createQuery("select a from Account a where a.accountId=?1",Account.class);
		q.setParameter(1,accId);
		List result = q.getResultList();
		if(result.size()!=0){
		Iterator stIterator=result.iterator();
		while(stIterator.hasNext()){
			Account acc=(Account)stIterator.next();
			System.out.println("Your account details are");
			System.out.println("Account_id : "+acc.getAccountId());
			System.out.println("Account_Name : "+acc.getAccountName());
			System.out.println("Address : "+acc.getAddress());
			System.out.println("Account Deposit : "+acc.getDepositAmount());
		}
		}
		else{
		System.out.println("Record not found.");
		}
		em.getTransaction().commit();
		return null;	
	}
	public Loan getLoanDetails(String loanId) {
		em.getTransaction().begin();
		
		Query q = em.createQuery("select l from Loan l where l.loanId=?1",Loan.class);
		q.setParameter(1,loanId);
		List result = q.getResultList();
		if(result.size()!=0){
		Iterator stIterator=result.iterator();
		while(stIterator.hasNext()){
			Loan loan=(Loan)stIterator.next();
			System.out.println("Your loan details are");
			System.out.println("Loan_id : "+loan.getLoanId());
			System.out.println("Loan_Name : "+loan.getLoanType());
			System.out.println("Loan_Amount : "+loan.getLoanAmount());
		}
		}
		else{
		System.out.println("Record not found.");
		}
		em.getTransaction().commit();
		return null;
		
	}	

   public double payLoan(String id, double amt)  {
	   em.getTransaction().begin();
	   TypedQuery<Account> query = (TypedQuery<Account>) em.createQuery("select acc from Account acc where acc.loanId= ?1");
	   query.setParameter(1,id);
       double accBal= ((Loan) query.getSingleResult()).getLoanAmount();
       TypedQuery<Loan> tl = (TypedQuery<Loan>) em.createQuery("update Account acc set acc.loanAmount = ?1 where acc.loanId= ?2");
       tl.setParameter(1, accBal-amt);
       tl.setParameter(2, id);
       int i=tl.executeUpdate();
       em.getTransaction().commit();
       if(i>0)
		return accBal-amt;
	   return -1;
	   }
}