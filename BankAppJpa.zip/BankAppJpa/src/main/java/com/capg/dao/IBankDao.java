package com.capg.dao;

import com.capg.bean.Account;
import com.capg.bean.Loan;

public interface IBankDao {

	public void createAccount(Account a);
	public void applyLoan(Loan loan);
	public Account getAccDetails(String accId);
	public Loan getLoanDetails(String loanId);
	public double deposit(String id, double depositAmount);
	public double withdraw(String id, double withdraw);
	public double payLoan(String id, double amt);
}
