package com.capg.dao;

import java.util.function.Predicate;

public class Filter {
	
	public Predicate<String> nameStartingWithPrefix(String prefix){
		return name->name.startsWith(prefix);
	}

}
