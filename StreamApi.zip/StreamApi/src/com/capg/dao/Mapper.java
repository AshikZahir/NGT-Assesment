package com.capg.dao;

import java.util.ArrayList;
import java.util.function.Function;

import com.capg.bean.CharactersCount;

public class Mapper {
	
	public Function<String,  CharactersCount> getDistinctCharactersCount(){
		return c->{
			ArrayList<Character> unique = new ArrayList<Character>();
		     for( int i = 0; i < c.length(); i++) {
		         if( !unique.contains( c.charAt( i ) ) ) {
		             unique.add( c.charAt( i ) );
		         }
		     }
		     return new CharactersCount(c, unique.size());
			};
		}
}