package com.capg.service;

import java.util.Arrays;
import java.util.List;

import com.capg.dao.Filter;
import com.capg.dao.Mapper;
import com.capg.bean.CharactersCount;

public class MainApp {

	public static void main(String[] args) {
		List<String> l = Arrays.asList("aaryanna", "aayanna", "airianna", "alassandra", "allanna", "allannah",
		                                "allessandra", "allianna", "allyanna", "anastaisa", "anastashia", "anastasia", "annabella", "annabelle",
		                                "annebelle");
		Filter f = new Filter();
		Mapper m = new Mapper();
		l.stream().filter(f.nameStartingWithPrefix("aa"))
		.map(m.getDistinctCharactersCount())
		.forEach(System.out::println);
		}

}
