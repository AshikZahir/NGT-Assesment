package org.capg.dao;

import org.capg.model.BookDetails;
import org.capg.model.LibraryDetails;

public interface IDaoLibrary {

	void addnewbooks(LibraryDetails library);

	BookDetails findBookID(String bookId);

	BookDetails updateBookDetails(String nbId, String nBName, String nBauthr, String nBpubshr);

	LibraryDetails findBook(String libraryId);

	void deleteBook(String libraryId);

}