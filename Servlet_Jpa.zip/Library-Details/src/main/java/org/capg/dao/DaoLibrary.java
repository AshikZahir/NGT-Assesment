package org.capg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.capg.model.BookDetails;
import org.capg.model.LibraryDetails;

public class DaoLibrary {

	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("my");
	private static EntityManager em = emf.createEntityManager();
	private static EntityTransaction tx = em.getTransaction();

	public void addnewbooks(LibraryDetails library) {

		System.out.println("Add Book Check");
		tx.begin();
		em.persist(library);
		tx.commit();
		em.close();
		emf.close();
	}

	public BookDetails findBookID(String bookId) {

		return em.find(BookDetails.class, bookId);
	}

	public BookDetails updateBookDetails(String nbId, String nBName, String nBauthr, String nBpubshr) {
		BookDetails b = findBookID(nbId);
		em.getTransaction().begin();
		b.setBookName(nBName);
		b.setAuthor(nBauthr);
		b.setPublisher(nBpubshr);
		em.getTransaction().commit();
		return b;
	}

	public LibraryDetails findBook(String libraryId) {

		return em.find(LibraryDetails.class, libraryId);
	}

	public void deleteBook(String libraryId) {

		em.getTransaction().begin();
		LibraryDetails l = findBook(libraryId);
		em.remove(l);
		em.getTransaction().commit();

	}

}
