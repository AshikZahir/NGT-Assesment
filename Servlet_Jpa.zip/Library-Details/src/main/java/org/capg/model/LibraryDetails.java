package org.capg.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;



@Entity
public class LibraryDetails {
	
	@Id
	String libraryId;
	String libraryName;
	@OneToMany(mappedBy="library",cascade=CascadeType.ALL)
	List<BookDetails> book=new ArrayList<BookDetails>();
	
	public LibraryDetails(String libraryId, String libraryName, List<BookDetails> book) {
		super();
		this.libraryId = libraryId;
		this.libraryName = libraryName;
		this.book = book;
	}
	public LibraryDetails() {
		super();
	}
	public String getLibraryId() {
		return libraryId;
	}
	public void setLibraryId(String libraryId) {
		this.libraryId = libraryId;
	}
	public String getLibraryName() {
		return libraryName;
	}
	public void setLibraryName(String libraryName) {
		this.libraryName = libraryName;
	}
	public List<BookDetails> getBook() {
		return book;
	}
	public void setBook(List<BookDetails> book) {
		this.book = book;
	}
	@Override
	public String toString() {
		return "LibraryDetails [libraryId=" + libraryId + ", libraryName=" + libraryName + ", book=" + book + "]";
	}
	
	
	

}
