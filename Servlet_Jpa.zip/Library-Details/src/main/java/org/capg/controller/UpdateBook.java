package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.dao.DaoLibrary;
import org.capg.model.BookDetails;

/**
 * Servlet implementation class UpdateBook
 */

@WebServlet("/updateBook")
public class UpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		DaoLibrary dao = new DaoLibrary();

		String nbId = request.getParameter("bId");
		String nBName = request.getParameter("bName");
		String nBauthr = request.getParameter("Authr");
		String nBpubshr = request.getParameter("Pubshr");

		BookDetails book = dao.findBookID(nbId);

		BookDetails upbook = dao.updateBookDetails(nbId, nBName, nBauthr, nBpubshr);

		out.println("After Updating");
		out.print("<br>");
		out.println("Book Name : " + upbook.getBookName());
		out.print("<br>");
		out.println("Book Author : " + upbook.getAuthor());
		out.print("<br>");
		out.println("Book Publisher Name : " + upbook.getPublisher());
		out.print("<br>");
	}

}
