package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.dao.DaoLibrary;
import org.capg.model.BookDetails;
import org.capg.model.LibraryDetails;

/**
 * Servlet implementation class SearchBook
 */
@WebServlet("/searchBook")
public class SearchBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DaoLibrary dao = new DaoLibrary();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		LibraryDetails l = dao.findBook(request.getParameter("sid"));

		if (l != null) {
			out.println("Library Id:" + l.getLibraryId());
			out.print("<br>");
			out.println("Library Name:" + l.getLibraryName());

		}

		BookDetails b = dao.findBookID(request.getParameter("sbid"));

		out.print("<br>");
		if (b != null) {
			out.println("Book Id : " + b.getBookId());
			out.print("<br>");
			out.println("Book Name : " + b.getBookName());
			out.print("<br>");
			out.println("Author of Book : " + b.getAuthor());
			out.print("<br>");
			out.println("Publisher of Book : " + b.getPublisher());
		} else {
			out.println("Enter the correct BookId");
		}
	}

}
