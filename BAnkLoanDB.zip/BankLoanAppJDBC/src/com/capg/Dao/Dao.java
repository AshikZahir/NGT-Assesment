package com.capg.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capg.bean.Account;
import com.capg.bean.Loan;

public class Dao implements IDao{

	PreparedStatement ps = null;
	PreparedStatement ps2 = null;
	PreparedStatement ps3 = null;
	Connection conn = null;

	@Override
	public void createAccount(Account account) throws Exception 
	{
		String acc_name = account.getAccountName();
		String acc_id = account.getAccountId();
		String address = account.getAddress();
		double deposit = account.getDepositAmount();
		
		String driver = "com.mysql.jdbc.Driver";
	    Class.forName(driver);
		String url="jdbc:mysql://localhost:3306/jdbcassignment?useSSL=false";
		String username="root";
		String password="1234";
			
		Connection conn = DriverManager.getConnection(url,username,password);
//		Statement stmt = conn.createStatement();
//		String sql = "create table Account(accountId varchar(20) primary key,accountName varchar(15) not null,address varchar(30),depositAmount double)";
//		stmt.executeUpdate(sql);
//	    System.out.println(" table created");
			
			ps = conn.prepareStatement("insert into Account values(?,?,?,?)");
			ps.setString(1, acc_id);
			ps.setString(2, acc_name);
			ps.setString(3, address);
			ps.setDouble(4, deposit);

			int query = ps.executeUpdate();

			if (query == 1) {
				System.out.println("Account created successfully!");
			}

			conn.close();

	}
@Override
	public double deposit(String id, double depositAmount) throws Exception {
		double newBalance;
		
			if (depositAmount > 0) {
				String driver = "com.mysql.jdbc.Driver";
				Class.forName(driver);
				String url="jdbc:mysql://localhost:3306/jdbcassignment?useSSL=false";
				String username="root";
				String password="1234";
				

				ps3 = conn.prepareStatement("select depositAmount from account");
				ResultSet rs = ps3.executeQuery();

				ps = conn.prepareStatement("update account set depositAmount= ? where accountId=?");

				if (rs.next()) {
					double bal1 = rs.getDouble("depositAmount");
					newBalance = bal1 + depositAmount;

					ps.setDouble(1, newBalance);
					ps.setString(2, id);

					int query = ps.executeUpdate();

					if (query > 0) {
						System.out.println("Money deposited scucessfully!");
						return newBalance;
					}
					conn.close();
				}
			}
		
		return 0;
	}
@Override
	public double withdraw(String id, double withdraw) throws Exception {
		double newBalance;
		
			if (withdraw > 0) {
				
				String driver = "com.mysql.jdbc.Driver";
				Class.forName(driver);
				String url="jdbc:mysql://localhost:3306/jdbcassignment?useSSL=false";
				String username="root";
				String password="1234";
			    conn = DriverManager.getConnection(url,username,password);
				ps3 = conn.prepareStatement("select depositAmount from account");
				ResultSet rs = ps3.executeQuery();
				ps = conn.prepareStatement("update account set depositAmount= ? where accountId=?");
				if (rs.next()) {
					double bal1 = rs.getDouble("depositAmount");
					newBalance = bal1 - withdraw;
					ps.setDouble(1, newBalance);
					ps.setString(2, id);
					int query = ps.executeUpdate();
					if (query > 0) {
						System.out.println("Money withdrawn successfully! ");
						return newBalance;
					}
					conn.close();
				}
			}
		
		return 0;
	}

@Override
public void applyLoan(Loan loan) throws Exception {
		String loan_id = loan.getLoanId();
		String loan_type = loan.getLoanType();
		double loan_amount = loan.getLoanAmount();

			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			String url="jdbc:mysql://localhost:3306/jdbcassignment?useSSL=false";
			String username="root";
			String password="1234";
		    conn = DriverManager.getConnection(url,username,password);
		    Statement stmt = conn.createStatement();
			/*String sql = "create table Loan(loanId varchar(20) primary key,loanType varchar(15) not null,loanmAmount double)";
			stmt.executeUpdate(sql);
	        System.out.println(" table created");*/
			ps = conn.prepareStatement("insert into Loan values(?,?,?)");
			ps.setString(1, loan_id);
			ps.setString(2, loan_type);
			ps.setDouble(3, loan_amount);

			int query = ps.executeUpdate();

			if (query == 1) {
				System.out.println("Loan applied successfully!");
			}

			conn.close();

	}
@Override
	public double payLoan(String loan_id, double loan_amount) throws Exception {
		double newBalance;
		
			if (loan_amount > 0) {
				String driver = "com.mysql.jdbc.Driver";
				Class.forName(driver);
				String url="jdbc:mysql://localhost:3306/jdbcassignment?useSSL=false";
				String username="root";
				String password="1234";
			    conn = DriverManager.getConnection(url,username,password);
				ps3 = conn.prepareStatement(
						"select loan.loanmAmount, account.depositAmount from loan inner join account on loan.loanId = account.accountId");
				ResultSet rs = ps3.executeQuery();

				ps = conn.prepareStatement("update account set depositAmount = ?  where accountId= ?");
				ps2 = conn.prepareStatement("update loan set loanmAmount= ? where loanId = ?");

				if (rs.next()) {
					double bal1 = rs.getDouble("depositAmount");
					newBalance = bal1 - loan_amount;

					double bal2 = rs.getDouble("loanmAmount");
					double loanRem = bal2 - loan_amount;

					ps.setDouble(1, newBalance);
					ps.setString(2, loan_id);
					ps2.setDouble(1, loanRem);
					ps2.setString(2, loan_id);

					int sa = ps.executeUpdate();
					int sq = ps2.executeUpdate();

					if (sa == 1) {
						System.out.println("Loan paid successfully! Remaining loan amount is: "+ loanRem);
						return newBalance;
					}
					conn.close();
				}
			}
		
		return 0;
	}
@Override
	public Account getAccountDetails(String id) throws Exception {
		
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			String url="jdbc:mysql://localhost:3306/jdbcassignment?useSSL=false";
			String username="root";
			String password="1234";
		    conn = DriverManager.getConnection(url,username,password);ps = conn.prepareStatement("select accountId, accountName, address, depositAmount from Account where accountId = ?");
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Account acc = new Account();
				acc.setAccountId(rs.getString("accountId"));
				acc.setAccountName(rs.getString("accountName"));
				acc.setAddress(rs.getString("address"));
				acc.setDepositAmount(rs.getDouble("depositAmount"));
				return acc;
			}
			conn.close();
		
		return null;

	}
@Override
	public Loan getLoanDetails(String loan_id) throws Exception {
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			String url="jdbc:mysql://localhost:3306/jdbcassignment?useSSL=false";
			String username="root";
			String password="1234";
		    conn = DriverManager.getConnection(url,username,password);ps = conn.prepareStatement("select loanId, loanType, loanmAmount from loan where loanId = ?");
			ps.setString(1, loan_id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Loan l = new Loan();
				l.setLoanId(rs.getString("loanId"));
				l.setLoanType(rs.getString("loanType"));
				l.setLoanAmount(rs.getDouble("loanmAmount"));
				return l;
			}
			conn.close();
		
		return null;
	}

}
