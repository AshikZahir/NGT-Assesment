package com.capg.Dao;

import java.io.IOException;
import java.sql.SQLException;

import com.capg.bean.Account;
import com.capg.bean.Loan;

public interface IDao {
	public void createAccount(Account account) throws Exception;
	public double deposit(String id, double depositAmount) throws Exception;
	public double withdraw(String id, double withdraw) throws Exception;
	public void applyLoan(Loan loan) throws Exception;
	public double payLoan(String loan_id, double loan_amount) throws Exception;
	public Account getAccountDetails(String id) throws Exception;
	public Loan getLoanDetails(String loan_id) throws Exception;
}
