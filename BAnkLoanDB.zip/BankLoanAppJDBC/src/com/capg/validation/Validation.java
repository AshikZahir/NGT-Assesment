package com.capg.validation;

public class Validation {

	public boolean validateAccountName(String accountName) {
		String pattern="^[a-zA-Z]*$";
        return accountName.matches(pattern);
	}

	public boolean validateAccountId(String accountId) {
		 String pattern="^[1-9]{5}$";
			return accountId.matches(pattern);	
		
	}
}
