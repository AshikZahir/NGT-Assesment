package com.capg.grocery.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.capg.grocery.bean.Product;
import com.capg.grocery.bean.ProductType;
import com.capg.grocery.bean.User;
import com.capg.grocery.bean.UserType;
import com.capg.grocery.service.GroceryBillService;

class GroceryBillTest {
	static List<Product> productsList;
	static User employee,customer,affiliate;
	static GroceryBillService service;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception 
	{
		service = new GroceryBillService();
		productsList = new ArrayList<Product>(Arrays.asList(
				new Product(1,"Tv",1,50000.0,ProductType.APPLIANCES),
				new Product(2,"Caulifoer",3,50.0,ProductType.GROCERIES),
				new Product(3,"Tomato",2,20.0,ProductType.GROCERIES)));
		
		LocalDate employeeJoinedDate = LocalDate.parse("2018-05-22");
		LocalDate registeredDate = LocalDate.parse("2017-02-01");
		employee = new User(101, "Ashik", UserType.EMPLOYEE, employeeJoinedDate, productsList);
		affiliate = new User(102, "Ahamed", UserType.AFFILIATE, LocalDate.now(), productsList);
		customer = new User(103, "Zahir", UserType.CUSTOMER, registeredDate, productsList);
	}

	@Test
	void calculateBillForEmployee() 
	{
		assertEquals(33435.0, service.calculateBillAmount(employee));
	}
	
	@Test
	void calculateBillForAffliate() 
	{
		assertEquals(42935.0, service.calculateBillAmount(affiliate));
	}
	
	@Test
	void calculateBillForRegularCustomer() 
	{
		assertEquals(45310.0, service.calculateBillAmount(customer));
	}

}
