package com.capg.grocery.bean;

public enum ProductType {
	
	GROCERIES,APPLIANCES;
}
