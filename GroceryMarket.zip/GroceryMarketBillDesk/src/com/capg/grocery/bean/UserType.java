package com.capg.grocery.bean;

public enum UserType {
	
	EMPLOYEE,AFFILIATE,CUSTOMER;

}
