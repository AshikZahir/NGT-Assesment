package com.capg.grocery.service;

import java.time.LocalDate;


import com.capg.grocery.bean.Product;
import com.capg.grocery.bean.ProductType;
import com.capg.grocery.bean.User;
import com.capg.grocery.bean.UserType;

public class GroceryBillService 
{
	public double calculateBillAmount(User user)
	{
		
		double discount=0.0, totalCost=0.0, nonGrocery=0.0, groceryAmnt=0.0;
		int generalDiscount=0;
		
		for(Product product : user.getProduct())
		{
			
			if(product.getProductType() == ProductType.GROCERIES)
				groceryAmnt = groceryAmnt + (product.getNoOfItems()*product.getCostOfItem());
			else
				nonGrocery = nonGrocery +(product.getNoOfItems()*product.getCostOfItem());
		}
		
		if(user.getUserType() == UserType.EMPLOYEE) 
		{
			discount=nonGrocery*0.30;
			totalCost=(groceryAmnt + nonGrocery)-discount;
		}
		else if(user.getUserType() == UserType.AFFILIATE)
		{
			discount=nonGrocery*0.10;
			totalCost=(groceryAmnt + nonGrocery)-discount;
		}
		else if(user.getUserType() == UserType.CUSTOMER) 
		{
			int yearDiff=LocalDate.now().getYear() - user.getRegistrationDate().getYear();
			if(yearDiff >= 2) 
			{
				discount=nonGrocery*0.05;
				totalCost=(groceryAmnt + nonGrocery) - discount;
			}
		}
		else 
			totalCost = (groceryAmnt + nonGrocery);
		
		
		generalDiscount = (int)totalCost/100;
		totalCost = totalCost - (generalDiscount*5);
		return totalCost;
		
	}
}



