package com.capgemini.user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.bean.EmployeeBean;
import com.capgemini.data.EmployeeData;
import com.capgemini.validate.Validate;



public class UserDetails {
public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		Validate validation=new Validate();
		EmployeeData data=new EmployeeData();
		
		while (true) {
			
			System.out.println("Choose any one");
			System.out.println("1. Add Employee");
			System.out.println("2. Sort by EmployeeId");
			System.out.println("3. Sort by FirstName");
			System.out.println("4. Sort by LastName");
			System.out.println("5. Sort by Salary");
			System.out.println("6. Sort by Address");
			System.out.println("7. Sort by Department");
			System.out.println("8. Exit");
		
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				EmployeeBean emp=new EmployeeBean();
				System.out.println("Enter employee id");
				
				while (true) {
						String employeeId=sc.next();
						if (validation.employeeIdValidation(employeeId)) {
							if(!data.map.containsKey(employeeId)) {
							emp.setEmployeeId(employeeId);
							break;
							}
							else {
								System.out.println("Enter unique Employee ID");
							}
						}
						else
							System.out.println("Enter valid Employee ID");
					}
				
				System.out.println("Enter first name");
				while (true) {
					String firstname=sc.next();
					if (validation.employeeNameValidation(firstname)) {
							emp.setFirstName(firstname);
						break;
					}
					else
						System.out.println("Enter name in alphabets");
				}
				System.out.println("Enter last name");
				while (true) {
					String lastname=sc.next();
					if (validation.employeeNameValidation(lastname)) {
						emp.setLastName(lastname);
						break;
					}
					else
						System.out.println("Enter name in alphabets");
				}
				
				System.out.println("Enter employee salary");
				while (true) {
					int salary=sc.nextInt();
					if (validation.salaryValidation(salary)) {
						emp.setSalary(salary);
						break;
					}
					else
						System.out.println("Enter salary between 20000 and 5Lakhs");
				}
				System.out.println("Enter the date of joining");
				while (true) {
					String doj=sc.next();
					if (validation.dateValidation(doj)) {
						emp.setDateOfJoining(doj);
						break;
					}
					else
						System.out.println("Previous dates are not allowed");
				}
				
				System.out.println("Enter department name");
				emp.setDepartment(sc.next());
				
				System.out.println("Enter address");
				emp.setAddress(sc.next());
				
				data.map.put(emp.getEmployeeId(), emp);
				System.out.println("Employee created"+data.map);
				break;
				
			case 2:
				Set<Entry<String,EmployeeBean>>entrySet1=data.map.entrySet();
				List<Entry<String,EmployeeBean>> list1=new ArrayList<Map.Entry<String,EmployeeBean>>(entrySet1);
				Collections.sort(list1, new Comparator<Entry<String,EmployeeBean>>() {

					@Override
					public int compare(Entry<String, EmployeeBean> o1, Entry<String, EmployeeBean> o2) {
						
						return o1.getValue().getEmployeeId().compareTo(o2.getValue().getEmployeeId());
					}
				});
				System.out.println("Sorted based on emp id");
				list1.forEach(s->{
					System.out.println("\t"+s.getValue().getEmployeeId()+"\t"+s.getValue().getFirstName());
				});
				 break;
			case 3:{
				Set<Entry<String,EmployeeBean>>entrySet=data.map.entrySet();
				List<Entry<String,EmployeeBean>> list=new ArrayList<Map.Entry<String,EmployeeBean>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,EmployeeBean>>() {

					@Override
					public int compare(Entry<String, EmployeeBean> o1, Entry<String, EmployeeBean> o2) {
						
						return o1.getValue().getFirstName().compareTo(o2.getValue().getFirstName());
					}
				});
				System.out.println("Sorted based on first name");
				list.forEach(s->{
					System.out.println(s.getKey()+"\t"+s.getValue().getFirstName());
				});
				break; 
			}
			case 4:{
				Set<Entry<String,EmployeeBean>>entrySet=data.map.entrySet();
				List<Entry<String,EmployeeBean>> list=new ArrayList<Map.Entry<String,EmployeeBean>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,EmployeeBean>>() {

					@Override
					public int compare(Entry<String, EmployeeBean> o1, Entry<String, EmployeeBean> o2) {
						
						return o1.getValue().getLastName().compareTo(o2.getValue().getLastName());
					}
				});
				System.out.println("Sorted based on last name");
				list.forEach(s->{
					System.out.println(s.getKey()+"\t"+s.getValue().getLastName());
				});
				break; 
			}
			case 5:{
				Set<Entry<String,EmployeeBean>>entrySet=data.map.entrySet();
				List<Entry<String,EmployeeBean>> list=new ArrayList<Map.Entry<String,EmployeeBean>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,EmployeeBean>>() {

					@Override
					public int compare(Entry<String, EmployeeBean> o1, Entry<String, EmployeeBean> o2) {
						
						return o1.getValue().getSalary().compareTo(o2.getValue().getSalary());
					}
				});
				System.out.println("Sorted based on salary");
				list.forEach(s->{
					System.out.println(s.getKey()+"\t"+s.getValue().getFirstName()+"\t"+s.getValue().getSalary());
				});
				break; 
			}
			case 6:{
				Set<Entry<String,EmployeeBean>>entrySet=data.map.entrySet();
				List<Entry<String,EmployeeBean>> list=new ArrayList<Map.Entry<String,EmployeeBean>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,EmployeeBean>>() {

					@Override
					public int compare(Entry<String, EmployeeBean> o1, Entry<String, EmployeeBean> o2) {
						
						return o1.getValue().getAddress().compareTo(o2.getValue().getAddress());
					}
				});
				System.out.println("Sorted based on address id");
				list.forEach(s->{
					System.out.println(s.getKey()+"\t"+s.getValue().getAddress());
				});
				break; 
			}
			case 7:{
				Set<Entry<String,EmployeeBean>>entrySet=data.map.entrySet();
				List<Entry<String,EmployeeBean>> list=new ArrayList<Map.Entry<String,EmployeeBean>>(entrySet);
				Collections.sort(list, new Comparator<Entry<String,EmployeeBean>>() {

					@Override
					public int compare(Entry<String, EmployeeBean> o1, Entry<String, EmployeeBean> o2) {
						
						return o1.getValue().getDepartment().compareTo(o2.getValue().getDepartment());
					}
				});
				System.out.println("Sorted based on dept id");
				list.forEach(s->{
					System.out.println(s.getKey()+"\t"+s.getValue().getDepartment());
				});
				break; 
			}
			case 8:System.out.println("Thank you!");
			break;
	}

}
}

}
