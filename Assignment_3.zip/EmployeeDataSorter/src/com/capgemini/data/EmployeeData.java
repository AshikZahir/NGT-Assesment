package com.capgemini.data;

import java.util.Map;
import java.util.TreeMap;

import com.capgemini.bean.EmployeeBean;

public class EmployeeData {
	
	public Map<String,EmployeeBean> map;
	public EmployeeData() {
		map = new TreeMap<String,EmployeeBean>();
	}

	
}
