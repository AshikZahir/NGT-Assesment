package com.xyzbank;


public class Account { 
	
	private String accountId;
	private String accountName;
	private String address;
	private double depositAmount;
	
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}
	
		
	public Account() {
		super();
	}
	public Account(String accountId, String accountName, String address, double depositAmount) {
		this.accountId = accountId;
		this.accountName = accountName;
		this.address = address;
		this.depositAmount = depositAmount;
	}
	
	/*
	 * Account account[] = { new Account("0123400-AAAA", "Ashik", "Chennai",
	 * 5000.00), new Account("0123401-BBBB", "Zahir", "Aduthurai", 5000.00), new
	 * Account("0123402-cccc", "Ahamed", "Kumbakonam", 5000.00), new
	 * Account("0123403-DDDD", "Azz", "Dreamland", 5000.00); 
	 * 
	 * ArrayList<Account> accounts = new ArrayList<Account>(Arrays.asList(account));
	 */
	
	public Account getDetails(String id, Account accounts[]) {
		for(Account  account : accounts) {
			if((account.getAccountId()).equals(id)) {
				return account;
			}
		}		
		return null;		
	}
	
	public boolean showDetails(String id, Account accounts[]) {
		for(Account  account : accounts) {
			if((account.getAccountId()).equals(id)) {
				System.out.println("Account ID: "+account.getAccountId());
				System.out.println("Account Name: "+account.getAccountName());
				System.out.println("Address: "+account.getAddress());
				System.out.println("Balance Amount: "+account.getDepositAmount());
				return true;
				}
			}
		return false;
	}
	
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountName=" + accountName + ", address=" + address
				+ ", depositAmount=" + depositAmount + "]";
	}
	
	
	
	

}
