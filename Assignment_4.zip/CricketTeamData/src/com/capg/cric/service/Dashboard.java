package com.capg.cric.service;

import java.util.Scanner;

import com.capg.cric.matchlist.Match;
import com.capg.cric.matchlist.MatchBO;
import com.capg.cric.playerlist.Player;
import com.capg.cric.playerlist.PlayerBO;
import com.capg.cric.teamlist.Team;
import com.capg.cric.teamlist.TeamBO;

public class Dashboard {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MatchBO mo = new MatchBO();
		PlayerBO po = new PlayerBO();
		TeamBO to = new TeamBO();
		
		int playerCount;
		System.out.println("Enter the player Count");
		playerCount = sc.nextInt();
		//Player pList;
			Player[]	pList = new Player[20];
		
		for(int i=1, j=0; i<=playerCount; i++, j++) {
			System.out.println(i+".Enter player Details");
			String playerdetails = sc.next();
			pList[j] = po.createPlayer(playerdetails);
			
			
		}
		Team[] tList = new Team[20];
		System.out.println("Enter the team Count");
		int teamCount = sc.nextInt();
		for(int i=1,j=0; i<=teamCount; i++,j++) {
			System.out.println(i+".Enter the team Details");
//			tList[i] = to.createTeam(sc.nextLine(),pList);
			String teamDetails = sc.next();
			tList[i]=to.createTeam(teamDetails, pList);
		}
		
		Match[] mList = new Match[20];
		System.out.println("Enter the team Count");
		int matchCount = sc.nextInt();
		for(int i=1,j=0; i<matchCount; i++,j++) {
			System.out.println(i+"Enter the team Details");
			String matchDetails = sc.next();
			mList[j]=mo.createMatch(matchDetails, tList);
		}
		
		do {
			System.out.println("Menu \n");
			System.out.println("1) Find Team \n");
	     	System.out.println("2) Find All Matches In A Specific Venue \n");
	     	System.out.println("Type 1 or 2\n");
			System.out.println("Enter your choice\n");
			int choice = sc.nextInt();
			switch(choice) {
			
			case 1 : System.out.println("Enter Match Date");
			String date=sc.next();
			mo.findTeam(date, mList);
			break;
			
			case 2: System.out.println("Enter team name for Details");
			        String tn=sc.next();
			        mo.findAllMatchesOfTeam(tn, mList);
			        break;
			        
			default : System.out.println("invalid Input");
			          break;
			
			}
	     	
		System.out.println("Do You wanna Continue Yes or No");
		}while(!(sc.next().equalsIgnoreCase("No")));
	
	}
	
}
