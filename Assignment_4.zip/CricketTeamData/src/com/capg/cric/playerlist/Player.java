package com.capg.cric.playerlist;

public class Player {

		private String name;
		private String skill;
		private String contry;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getSkill() {
			return skill;
		}
		public void setSkill(String skill) {
			this.skill = skill;
		}
		public String getContry() {
			return contry;
		}
		public void setContry(String contry) {
			this.contry = contry;
		}
		@Override
		public String toString() {
			return "Player [name=" + name + ", skill=" + skill + ", contry=" + contry + "]";
		}
		public Player(String name, String skill, String contry) {
			super();
			this.name = name;
			this.skill = skill;
			this.contry = contry;
		}

		
}
