package com.capg.cric.playerlist;

public class PlayerBO {

	public Player createPlayer (String data) {
		String playerData[] = data.split(",");
		Player player = new Player(playerData[0], playerData[1], playerData[2]);
		return player;
	}
}
