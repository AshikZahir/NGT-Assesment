package com.capg.cric.matchlist;

import com.capg.cric.teamlist.Team;

public class MatchBO {

	   Match m = new Match();

	public Match createMatch(String data,Team[] teamList)  {
		String matachData[]=data.split(",");
		m.setDate(matachData[0]);
		for(Team t : teamList) {
			if(t.getName().equals(matachData[1]))
				m.setTeamone(t);
		}
		
		for( 	Team t2 : teamList) {
			if(t2.getName().equals(matachData[2]))
				m.setTeamtwo(t2);
		}
	
		m.setVenue(matachData[3]);
		//Team t = new Team(data, null);
		
		return m;
		
	}
	
	public Team findTeam(String matchDate, Match[] matchList) {
	//Team findteam;
		for(Match m: matchList) {
			Team findteam = null;
			if(m.getDate().equals(matchDate))
				findteam=m.getTeamone();
			Team findteam2 = m.getTeamtwo();
			
				System.out.println(findteam.getName()+" "+findteam2.getName());
				
		}
		return null;
	}
	
	public void findAllMatchesOfTeam(String teamName, Match[] matchList) {
		for( Match m: matchList) {
			if(m.getTeamone().equals(teamName) || m.getTeamtwo().equals(teamName))
				System.out.println(m);
		}
		
		
	}
}
