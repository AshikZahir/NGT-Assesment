package com.capg.cric.teamlist;

import com.capg.cric.playerlist.Player;

public class TeamBO {

	//private Player player;

	public Team createTeam(String data, Player[] PlayerList) {
		String teamData[] = data.split(",");
	//	Team team = new Team();
		
//		Player player = null;
	//	team.setName(teamData[0]);
		Team team = new Team(teamData[0], PlayerList);
		for(Player p : PlayerList)
		{
			if(p.getName().equals(teamData[1]));
//			player = p;
			team.setPlayer(p);
			
		}
		
		return team;
	}
}
