package com.capg.cric.teamlist;

import com.capg.cric.playerlist.Player;

public class Team {

	private String name;
	private Player player;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Player getPlayer() {
		return player;
	}
	public void setPlayer(Player player) {
		this.player = player;
	}
	@Override
	public String toString() {
		return "Team [name=" + name + ", player=" + player + "]";
	}
	public Team(String teamData, Player[] playerList) {
		super();
		this.name = name;
		this.player = player;
	}
//	public Team(String name, Player player) {
//		super();
//		this.name = name;
//		this.player = player;
//	}
	
	
}
