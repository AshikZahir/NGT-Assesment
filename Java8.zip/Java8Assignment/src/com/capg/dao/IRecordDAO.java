package com.capg.dao;

import java.util.ArrayList;
import java.util.List;

import com.capg.model.Record;

public interface IRecordDAO {
	
	public void compareRecords(ArrayList<Record> xlist, ArrayList<Record> ylist) throws Exception;
	public List<Record> getList();
	public StringBuilder getExactMatch();
	public StringBuilder getweakMatch();
	public StringBuilder getXBreak();
	
}
