package com.capg.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.junit.jupiter.api.Test;

import com.capg.dao.RecordDAO;
import com.capg.main.UserMain;
import com.capg.service.RecordService;

class UserMainTest {
 
	
	
	@Test
	void exactMatchtest() throws IOException {
		UserMain us = new UserMain();
		RecordService rs = new RecordService();
		File yfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Yset.txt");		        
		BufferedReader ybr = new BufferedReader(new FileReader(yfile));
		File xfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Xset.txt");
		BufferedReader xbr = new BufferedReader(new FileReader(xfile));
		StringBuilder b = rs.getExactMatch();
		if(ybr.equals(b) && xbr.equals(b))
		{
			assertEquals("x0y0", rs.getExactMatch());
		}
	//	boolean a = rs.getExactMatch().equals("x0y0");
		//assertEquals(false,a);
		xbr.close();
		ybr.close();
		
	}
	
	@Test
	void weakMatchTest() throws IOException {
		RecordService rs = new RecordService();
		File yfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Yset.txt");		        
		BufferedReader ybr = new BufferedReader(new FileReader(yfile));
		File xfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Xset.txt");
		BufferedReader xbr = new BufferedReader(new FileReader(xfile));
		StringBuilder b = rs.getWeakMatch();
		if(ybr.equals(b) && xbr.equals(b))
		{
			assertEquals("x1y1,x2y2,x3,y3,x6y6", b);
		}
		xbr.close();
		ybr.close();

	}
	@Test
	void xbreaktest() throws IOException {
		RecordService rs = new RecordService();
		File yfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Yset.txt");		        
		BufferedReader ybr = new BufferedReader(new FileReader(yfile));
		File xfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Xset.txt");
		BufferedReader xbr = new BufferedReader(new FileReader(xfile));
		StringBuilder b = rs.getXBreak();
		if(ybr.equals(b) && xbr.equals(b))
		{
			//assertEquals("x1y1,x2y2,x3,y3,x6y6", b);
			assertEquals("x4,x5,x7", b);
		}
		
		xbr.close();
		ybr.close();

	}
	@Test
	void ybreaktest() throws IOException {
		RecordService rs = new RecordService();
		File yfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Yset.txt");		        
		BufferedReader ybr = new BufferedReader(new FileReader(yfile));
		File xfile = new File("C:\\Users\\azahir\\Documents\\Practice txt files\\Xset.txt");
		BufferedReader xbr = new BufferedReader(new FileReader(xfile));
		StringBuilder b = rs.getYBreak();
		if(ybr.equals(b) && xbr.equals(b))
		{
			
			assertEquals("x4,x5,x7", b);
		}
		
		xbr.close();
		ybr.close();
	}
}
